// ── Constants ───────────────────────────────────────────────────────────────
// allorigins.win  → returns JSON { status: { http_code, url } }, free in production
// codetabs.com    → raw CORS proxy, response.status = actual HTTP status
const ALLORIGINS  = 'https://api.allorigins.win/get?url=';
const CODETABS    = 'https://api.codetabs.com/v1/proxy?quest=';
const CONCURRENCY = 3;   // keep low — we're using free third-party proxies
const TIMEOUT_MS  = 12000;

// ── State ───────────────────────────────────────────────────────────────────
const state = {
  activeTab: 'paste',
  pastedUrls: [],
  uploadedUrls: [],
  sitemapUrls: [],
  results: [],
  filter: 'all',
  checking: false,
  stopRequested: false,
};

// ── DOM refs ────────────────────────────────────────────────────────────────
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

const checkBtn         = $('checkBtn');
const clearBtn         = $('clearBtn');
const stopBtn          = $('stopBtn');
const urlCountEl       = $('urlCount');
const progressSection  = $('progressSection');
const progressFill     = $('progressFill');
const progressText     = $('progressText');
const progressErrors   = $('progressErrors');
const resultsSection   = $('resultsSection');
const resultsBody      = $('resultsBody');
const pasteArea        = $('pasteArea');
const fileInput        = $('fileInput');
const dropzone         = $('dropzone');
const browseLink       = $('browseLink');
const uploadedFilename = $('uploadedFilename');
const sitemapInput     = $('sitemapInput');
const sitemapLoadBtn   = $('sitemapLoadBtn');
const sitemapStatus    = $('sitemapStatus');
const downloadBtn      = $('downloadBtn');
const exampleBtn       = $('exampleBtn');
const emptyState       = $('emptyState');

// ── Tabs ────────────────────────────────────────────────────────────────────
$$('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    state.activeTab = tab.dataset.tab;
    $$('.tab').forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');
    $$('.tab-content').forEach(c => c.classList.add('hidden'));
    $(`${tab.dataset.tab}-content`).classList.remove('hidden');
    updateFooter();
  });
});

// ── Paste ───────────────────────────────────────────────────────────────────
pasteArea.addEventListener('input', () => {
  state.pastedUrls = parseLines(pasteArea.value);
  updateFooter();
});

function parseLines(text) {
  return [...new Set(
    text.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'))
  )];
}

// ── CSV Upload ───────────────────────────────────────────────────────────────
browseLink.addEventListener('click', (e) => { e.stopPropagation(); fileInput.click(); });
dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('dragover', (e) => { e.preventDefault(); dropzone.classList.add('drag-over'); });
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
dropzone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropzone.classList.remove('drag-over');
  if (e.dataTransfer.files[0]) processFile(e.dataTransfer.files[0]);
});
fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) processFile(fileInput.files[0]);
});

function processFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    state.uploadedUrls = parseCSV(e.target.result);
    uploadedFilename.textContent = `${file.name} — ${state.uploadedUrls.length} URL${state.uploadedUrls.length !== 1 ? 's' : ''} loaded`;
    uploadedFilename.classList.remove('hidden');
    updateFooter();
  };
  reader.readAsText(file);
}

function parseCSV(text) {
  const lines = text.split(/\r?\n/);
  const urls = new Set();
  const first = lines[0] ? lines[0].toLowerCase() : '';
  const startRow = /url|link|href|address/i.test(first) ? 1 : 0;

  for (let i = startRow; i < lines.length; i++) {
    for (const cell of splitCSVLine(lines[i])) {
      const val = cell.trim().replace(/^["']|["']$/g, '');
      if (val && /^https?:\/\//i.test(val)) urls.add(val);
      else if (val && /^(www\.|\w+\.\w{2,})/.test(val) && !val.includes(' ')) urls.add(val);
    }
  }
  return [...urls];
}

function splitCSVLine(line) {
  const result = [];
  let cur = '', inQuote = false;
  for (const ch of line) {
    if (ch === '"') { inQuote = !inQuote; continue; }
    if (ch === ',' && !inQuote) { result.push(cur); cur = ''; continue; }
    cur += ch;
  }
  result.push(cur);
  return result;
}

// ── Sitemap (client-side via allorigins proxy) ───────────────────────────────
sitemapLoadBtn.addEventListener('click', loadSitemap);
sitemapInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') loadSitemap(); });

async function loadSitemap() {
  const url = sitemapInput.value.trim();
  if (!url) return;

  sitemapLoadBtn.disabled = true;
  sitemapLoadBtn.textContent = 'Loading…';
  sitemapStatus.className = 'sitemap-status';
  sitemapStatus.textContent = 'Fetching sitemap…';
  sitemapStatus.classList.remove('hidden');

  try {
    const urls = await fetchSitemapUrls(url, 2);
    state.sitemapUrls = urls;
    sitemapStatus.textContent = `✓ ${urls.length.toLocaleString()} URLs found`;
    sitemapStatus.classList.add('ok');
  } catch (err) {
    state.sitemapUrls = [];
    sitemapStatus.textContent = `✗ ${err.message}`;
    sitemapStatus.classList.add('err');
  } finally {
    sitemapLoadBtn.disabled = false;
    sitemapLoadBtn.textContent = 'Load';
    updateFooter();
  }
}

async function fetchSitemapUrls(sitemapUrl, depth) {
  const res = await fetch(`${ALLORIGINS}${encodeURIComponent(sitemapUrl)}`);
  if (!res.ok) throw new Error(`Failed to fetch sitemap (HTTP ${res.status})`);
  const data = await res.json();
  const xml = data.contents;
  if (!xml) throw new Error('Empty sitemap response');
  return parseSitemapXml(xml, depth);
}

async function parseSitemapXml(xml, depth) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, 'text/xml');

  if (doc.querySelector('parsererror')) throw new Error('Invalid XML in sitemap');

  // Sitemap index — recurse into child sitemaps
  const indexLocs = [...doc.querySelectorAll('sitemapindex > sitemap > loc')];
  if (indexLocs.length > 0) {
    if (depth <= 0) return [];
    const childUrls = indexLocs.slice(0, 15).map(el => el.textContent.trim());
    const nested = await Promise.all(
      childUrls.map(u =>
        fetch(`${ALLORIGINS}${encodeURIComponent(u)}`)
          .then(r => r.json())
          .then(d => parseSitemapXml(d.contents || '', depth - 1))
          .catch(() => [])
      )
    );
    return nested.flat();
  }

  // Regular sitemap
  return [...doc.querySelectorAll('url > loc')].map(el => el.textContent.trim());
}

// ── URL Normalisation ────────────────────────────────────────────────────────
function normalizeUrl(raw) {
  const url = String(raw || '').trim();
  if (!url) return null;
  const withProto = /^https?:\/\//i.test(url) ? url : `https://${url}`;
  try { new URL(withProto); return withProto; } catch { return null; }
}

// ── Client-side URL checker ──────────────────────────────────────────────────
// Attempt 1 – allorigins.win: returns JSON with http_code + the URL allorigins
//   ultimately fetched (which may differ from the original if it was redirected).
// Attempt 2 – api.codetabs.com: raw CORS proxy; response.status = real HTTP code.

async function checkUrl(rawUrl) {
  const t0 = Date.now();
  const url = normalizeUrl(rawUrl);

  if (!url) {
    return { originalUrl: rawUrl, finalUrl: null, statusCode: null, error: 'Invalid URL', redirects: 0, responseTime: 0 };
  }

  // ── Attempt 1: allorigins.win ────────────────────────────────────────────
  try {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), TIMEOUT_MS);
    const res = await fetch(`${ALLORIGINS}${encodeURIComponent(url)}`, { signal: controller.signal });
    clearTimeout(tid);

    if (res.ok) {
      const data = await res.json();
      const statusCode = data.status?.http_code || null;
      // allorigins stores the URL it actually fetched in status.url —
      // if it differs from what we sent, a redirect happened.
      const reportedUrl = data.status?.url || url;
      const finalUrl = /^https?:\/\//i.test(reportedUrl) ? reportedUrl : url;

      return {
        originalUrl: rawUrl,
        finalUrl,
        statusCode,
        redirects: finalUrl !== url ? 1 : 0,
        responseTime: Date.now() - t0,
      };
    }
  } catch (e1) {
    if (e1.name === 'AbortError') {
      return { originalUrl: rawUrl, finalUrl: url, statusCode: null, error: 'Timeout', redirects: 0, responseTime: TIMEOUT_MS };
    }
    // fall through
  }

  // ── Attempt 2: api.codetabs.com ─────────────────────────────────────────
  try {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), TIMEOUT_MS);
    const proxyUrl = `${CODETABS}${encodeURIComponent(url)}`;
    const res = await fetch(proxyUrl, { signal: controller.signal });
    clearTimeout(tid);

    // If codetabs browser-redirected to a new proxy URL, extract the final target.
    let finalUrl = url;
    if (res.url && res.url !== proxyUrl) {
      const candidate = decodeURIComponent(res.url.replace(CODETABS, ''));
      if (/^https?:\/\//i.test(candidate)) finalUrl = candidate;
    }

    return {
      originalUrl: rawUrl,
      finalUrl,
      statusCode: res.status,
      redirects: finalUrl !== url ? 1 : 0,
      responseTime: Date.now() - t0,
    };
  } catch (e2) {
    return {
      originalUrl: rawUrl,
      finalUrl: url,
      statusCode: null,
      error: e2.name === 'AbortError' ? 'Timeout' : 'Unreachable',
      redirects: 0,
      responseTime: Date.now() - t0,
    };
  }
}

// Concurrency-limited async map
async function concurrentMap(items, fn, limit, onEach) {
  const results = new Array(items.length);
  let cursor = 0;

  async function worker() {
    while (cursor < items.length) {
      const i = cursor++;
      if (state.stopRequested) break;
      results[i] = await fn(items[i]);
      onEach(i, results[i]);
    }
  }

  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}

// ── Footer helpers ───────────────────────────────────────────────────────────
function activeUrls() {
  switch (state.activeTab) {
    case 'paste':   return state.pastedUrls;
    case 'upload':  return state.uploadedUrls;
    case 'sitemap': return state.sitemapUrls;
  }
  return [];
}

function updateFooter() {
  const n = activeUrls().length;
  urlCountEl.textContent = `${n.toLocaleString()} URL${n !== 1 ? 's' : ''}`;
  clearBtn.classList.toggle('hidden', n === 0);
}

// ── Clear ────────────────────────────────────────────────────────────────────
clearBtn.addEventListener('click', () => {
  state.pastedUrls = state.uploadedUrls = state.sitemapUrls = [];
  pasteArea.value = '';
  uploadedFilename.classList.add('hidden');
  sitemapStatus.classList.add('hidden');
  fileInput.value = '';
  updateFooter();
});

// ── Check ────────────────────────────────────────────────────────────────────
checkBtn.addEventListener('click', startCheck);
stopBtn.addEventListener('click', () => {
  state.stopRequested = true;
  stopBtn.disabled = true;
  stopBtn.textContent = 'Stopping…';
});

async function startCheck() {
  if (state.checking) return;
  const urls = activeUrls();
  if (urls.length === 0) { alert('Add some URLs first.'); return; }

  state.checking = true;
  state.stopRequested = false;
  state.results = [];

  checkBtn.disabled = true;
  checkBtn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M10 15l5-3-5-3v6z"/></svg> Checking…';
  stopBtn.disabled = false;
  stopBtn.textContent = 'Stop';
  progressSection.classList.remove('hidden');
  resultsSection.classList.add('hidden');
  updateProgress(0, urls.length, 0);

  let completed = 0, errors = 0;

  await concurrentMap(urls, checkUrl, CONCURRENCY, (i, result) => {
    state.results.push(result);
    completed++;
    if (!result.statusCode) errors++;
    updateProgress(completed, urls.length, errors);
  });

  state.checking = false;
  checkBtn.disabled = false;
  checkBtn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg> Check URLs';
  progressSection.classList.add('hidden');

  if (state.results.length > 0) {
    renderResults();
    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function updateProgress(done, total, errors) {
  progressFill.style.width = (total > 0 ? (done / total) * 100 : 0) + '%';
  progressText.textContent = `${done.toLocaleString()} / ${total.toLocaleString()}`;
  progressErrors.textContent = errors > 0 ? `${errors} error${errors !== 1 ? 's' : ''}` : '';
}

// ── Results ──────────────────────────────────────────────────────────────────
$$('.filter').forEach(btn => {
  btn.addEventListener('click', () => {
    state.filter = btn.dataset.filter;
    $$('.filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderTable();
  });
});

$$('.summary-card').forEach(card => {
  card.addEventListener('click', () => {
    const f = card.dataset.filter;
    state.filter = f;
    $$('.filter').forEach(b => b.classList.remove('active'));
    document.querySelector(`.filter[data-filter="${f}"]`)?.classList.add('active');
    $$('.summary-card').forEach(c => c.classList.remove('active-filter'));
    card.classList.add('active-filter');
    renderTable();
  });
});

function category(r) {
  const c = r.statusCode;
  if (!c) return 'error';
  if (c >= 200 && c < 300) return '2xx';
  if (c >= 300 && c < 400) return '3xx';
  if (c >= 400 && c < 500) return '4xx';
  if (c >= 500) return '5xx';
  return 'error';
}

function renderResults() {
  const counts = { total: state.results.length, '2xx': 0, '3xx': 0, '4xx': 0, '5xx': 0, error: 0 };
  state.results.forEach(r => counts[category(r)]++);

  $('count-total').textContent = counts.total.toLocaleString();
  $('count-2xx').textContent   = counts['2xx'].toLocaleString();
  $('count-3xx').textContent   = counts['3xx'].toLocaleString();
  $('count-4xx').textContent   = counts['4xx'].toLocaleString();
  $('count-5xx').textContent   = counts['5xx'].toLocaleString();
  $('count-error').textContent = counts.error.toLocaleString();

  state.filter = 'all';
  $$('.filter').forEach(b => b.classList.remove('active'));
  document.querySelector('.filter[data-filter="all"]').classList.add('active');
  $$('.summary-card').forEach(c => c.classList.remove('active-filter'));

  renderTable();
}

function renderTable() {
  const rows = state.filter === 'all'
    ? state.results
    : state.results.filter(r => category(r) === state.filter);

  if (rows.length === 0) {
    resultsBody.innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }
  emptyState.classList.add('hidden');

  resultsBody.innerHTML = rows.map((r, i) => {
    const cat = category(r);
    const badgeClass = cat === 'error' ? 'badge-err' : `badge-${cat}`;
    const statusLabel = r.statusCode ? String(r.statusCode) : 'ERR';
    const errTitle = r.error ? ` title="${esc(r.error)}"` : '';
    const isRedirected = r.finalUrl && r.originalUrl !== r.finalUrl &&
                         !r.finalUrl.includes('corsproxy.io') &&
                         !r.finalUrl.includes('allorigins');

    return `<tr>
      <td class="col-num" style="color:var(--text-hint)">${i + 1}</td>
      <td class="url-cell"><a href="${esc(r.originalUrl)}" target="_blank" rel="noopener noreferrer" title="${esc(r.originalUrl)}">${esc(clip(r.originalUrl, 55))}</a></td>
      <td class="url-cell">${isRedirected
        ? `<a href="${esc(r.finalUrl)}" target="_blank" rel="noopener noreferrer" title="${esc(r.finalUrl)}">${esc(clip(r.finalUrl, 55))}</a>`
        : `<span class="same">—</span>`
      }</td>
      <td><span class="badge ${badgeClass}"${errTitle}>${statusLabel}</span></td>
      <td class="time-cell">${r.responseTime ? r.responseTime + 'ms' : '—'}</td>
      <td class="hops-cell">${r.redirects > 0 ? r.redirects : '—'}</td>
    </tr>`;
  }).join('');
}

function esc(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function clip(str, max) {
  if (!str || str.length <= max) return str || '';
  return str.slice(0, max) + '…';
}

// ── Download report ───────────────────────────────────────────────────────────
downloadBtn.addEventListener('click', () => {
  const header = ['#', 'Original URL', 'Final URL', 'Status Code', 'Response Time (ms)', 'Redirects', 'Error'];
  const rows = [header, ...state.results.map((r, i) => [
    i + 1, r.originalUrl || '', r.finalUrl || '', r.statusCode || '',
    r.responseTime || '', r.redirects || 0, r.error || '',
  ])];
  const csv = rows.map(row => row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\r\n');
  triggerDownload(csv, `status-check-${today()}.csv`, 'text/csv');
});

// ── Example CSV ───────────────────────────────────────────────────────────────
exampleBtn.addEventListener('click', () => {
  const csv = ['url', 'https://example.com', 'https://httpstat.us/200', 'https://httpstat.us/301',
    'https://httpstat.us/404', 'https://httpstat.us/500', 'https://google.com', 'https://github.com'].join('\r\n');
  triggerDownload(csv, 'example-urls.csv', 'text/csv');
});

function triggerDownload(content, filename, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement('a'), { href: url, download: filename });
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function today() {
  return new Date().toISOString().slice(0, 10);
}
